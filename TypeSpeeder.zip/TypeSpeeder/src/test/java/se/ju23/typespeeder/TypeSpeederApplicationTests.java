package se.ju23.typespeeder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TypeSpeederApplicationTests {

    @Test
    void contextLoads() {
    }

}
