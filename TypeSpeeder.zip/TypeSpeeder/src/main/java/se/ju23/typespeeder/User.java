package se.ju23.typespeeder;

import java.util.Optional;

public class User {


    public static void logIn() {

    }

    public static void logOut() {

    }

    public static void updateProfile() {
    }
}



