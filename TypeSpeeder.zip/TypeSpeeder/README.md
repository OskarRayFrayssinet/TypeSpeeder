Emelie Lind och Emelie Jansson arbetar i par med detta projekt.
